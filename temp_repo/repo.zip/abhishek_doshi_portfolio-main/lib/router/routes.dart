class Routes {
  static String home = '/';
  static String twitter = '/twitter';
  static String linkedin = '/linkedin';
  static String github = '/github';
  static String instagram = '/instagram';
  static String medium = '/medium';
  static String cv = '/cv';
  static String email = '/email';
  static String wasm = '/wasm';
  static String wasmExample = '/wasm-example';
}
