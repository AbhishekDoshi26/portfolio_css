class SkillLevelData {
  final String skill;
  final double level;

  SkillLevelData({
    required this.skill,
    required this.level,
  });
}
