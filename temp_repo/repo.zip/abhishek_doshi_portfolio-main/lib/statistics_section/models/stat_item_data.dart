class StatItemData {
  final int value;
  final String subtitle;

  StatItemData({required this.value, required this.subtitle});
}
